import numpy as np
import numerical_methods as nm

def fx(x):
    return x**2

def f_ode(x, y):
    return y

n = 100
print("Trapezoid:", nm.trapezoid(fx, n, 0.0, 1.0))
print("Simpson  :", nm.simpson(fx, n, 0.0, 1.0))
print("Gauss2   :", nm.gauss2(fx, 0.0, 1.0))

h = 0.1
steps = 10
print("Euler    :", nm.eulerrk2_exp(f_ode, 0.0, 1.0, h, steps))
print("RK2      :", nm.rk2rk2_exp(f_ode, 0.0, 1.0, h, steps))
# print("Expected :", np.exp(1.0))