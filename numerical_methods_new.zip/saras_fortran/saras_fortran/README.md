{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 .AppleSystemUIFontMonospaced-Regular;}
{\colortbl;\red255\green255\blue255;\red214\green85\blue98;\red155\green162\blue177;}
{\*\expandedcolortbl;;\cssrgb\c87843\c42353\c45882;\cssrgb\c67059\c69804\c74902;}
\margl1440\margr1440\vieww23620\viewh14100\viewkind0
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0

\f0\fs26 \cf2 # numerical_methods\
\
**numerical_methods** is a Python wrapper for Fortran numerical routines. It allows to use high-performance Fortran code directly from Python.\
\
## Features\
\
\pard\tx560\tx1120\tx1680\tx2240\tx2725\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0
\cf2 - Efficient numerical methods implemented in Fortran\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0
\cf2 - Easy-to-use Python interface\
- Can be installed via `pip` from a wheel or source\
\
## Installation\
\
### Option 1: Install from PyPI (if published)\
```bash\
pip install numerical_methods\
\
## Installation via wheel file\
\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0
\cf3 pip install dist/numerical_methods-0.1-cp3XX-cp3XX-macosx_XX_X.whl # name of the .whl file in the dist folder}