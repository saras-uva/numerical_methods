from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext
import numpy
import subprocess
import os
import shutil

class F2PyBuildExt(build_ext):
    def build_extensions(self):
        for ext in self.extensions:
            src = ext.sources[0]
            modname = ext.name
            print(f"🔧 Building Fortran extension {modname} from {src} ...")

            # Run f2py to compile Fortran → .so file
            subprocess.run(
                ["python", "-m", "numpy.f2py", "-c", "-m", modname, src],
                check=True
            )

            # Find the compiled .so file in current directory
            for f in os.listdir("."):
                if f.startswith(modname) and f.endswith(".so"):
                    build_path = os.path.join(self.build_lib, f"{modname}.so")
                    os.makedirs(self.build_lib, exist_ok=True)
                    shutil.move(f, build_path)
                    print(f"✅ Moved compiled module to {build_path}")
                    break
        print("✅ Fortran extension built successfully!")

ext_modules = [
    Extension(
        name="numerical_methods",
        sources=["numerical_methods.f90"],
    )
]

setup(
    name="numerical_methods",
    version="0.1",
    description="Numerical methods Fortran extension (built via f2py)",
    author="Saraswati Pandey",
    license="MIT",
    ext_modules=ext_modules,
    cmdclass={"build_ext": F2PyBuildExt},
    include_dirs=[numpy.get_include()],
)
